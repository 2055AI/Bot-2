#include "abstractEncoder.hpp"

using namespace lib16868C;

int AbstractEncoder::getTPR() {
	return tpr;
}