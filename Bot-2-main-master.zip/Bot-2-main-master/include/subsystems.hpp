#pragma once

void setIntake(int power);
void setIntakeMotors();

void setCata(int power);
void cataShoot();
void cataShootV2();
void cataHangPrep();
void cataHangElevate();
void AllowContinue();
void intakeShoot();
void intakeReset();